////////////////////////////////////////////////////////////////////////////////
//   ____  ____   
//  /   /\/   /  
// /___/  \  /   
// \   \   \/  
//  \   \        Copyright (c) 2003-2004 Xilinx, Inc.
//  /   /        All Right Reserved. 
// /---/   /\     
// \   \  /  \  
//  \___\/\___\
////////////////////////////////////////////////////////////////////////////////

#ifndef H_Work_data_packer_synth_H
#define H_Work_data_packer_synth_H
#ifdef __MINGW32__
#include "xsimMinGW.h"
#else
#include "xsim.h"
#endif


class Work_data_packer_synth: public HSim__s6 {
public:

    HSim__s1 SE[19];

  HSimEnumType State_type;
  char *t0;
  char *t1;
  char *t2;
  char *t3;
    HSim__s1 SA[6];
    Work_data_packer_synth(const char * name);
    ~Work_data_packer_synth();
    void constructObject();
    void constructPorts();
    void reset();
    void architectureInstantiate(HSimConfigDecl* cfg);
    virtual void vhdlArchImplement();
};



HSim__s6 *createWork_data_packer_synth(const char *name);

#endif
